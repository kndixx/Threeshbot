CONFIG_FILE_NAME = "config.ini"

CFG_GENERAL = 'general'
CFG_POSTGRESQL = 'postgresql'

CFG_TOKEN = 'token'
CFG_COMMAND_START = 'command_start'
CFG_GENERATE_MSG_CHANCE = 'generate_msg_chance'

TXT_COMMAND_NOT_FOUND = 'Прости, дружок, но такой команды нет!'

CMD_HELLO = 'привет'
CMD_HELLO_REPLY = 'Привет!'