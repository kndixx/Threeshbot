"""
Defines commands for the bot, which can be used in
bot's implementation
"""

from .cmd_hello import *

commands = [cmd_hello]